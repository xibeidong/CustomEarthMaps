var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz",
  1: "abcdefgilmnoprstvw",
  2: "abcdefghilmnopqrstuvwz",
  3: "_abcdefghijklmnopqrstuvwxyz",
  4: "acdeilmoprtuvw",
  5: "abcdefghiklmnoprstw",
  6: "abcdefhilmnoprstuvwxyz",
  7: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Properties",
  7: "Pages"
};

