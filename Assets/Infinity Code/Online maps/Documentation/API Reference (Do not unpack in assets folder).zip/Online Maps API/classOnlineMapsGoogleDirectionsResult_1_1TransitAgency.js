var classOnlineMapsGoogleDirectionsResult_1_1TransitAgency =
[
    [ "name", "classOnlineMapsGoogleDirectionsResult_1_1TransitAgency.html#aaa52ec404f75b99ef6a24ea03b7f8fde", null ],
    [ "phone", "classOnlineMapsGoogleDirectionsResult_1_1TransitAgency.html#aa65571c8e1422ffa1bf43d6bfeceba6e", null ],
    [ "url", "classOnlineMapsGoogleDirectionsResult_1_1TransitAgency.html#a8860ad3f74ea76a1231424dbb26e3690", null ]
];