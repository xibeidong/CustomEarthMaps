var classOnlineMapsBingMapsElevationResult =
[
    [ "Resource", "classOnlineMapsBingMapsElevationResult_1_1Resource.html", "classOnlineMapsBingMapsElevationResult_1_1Resource" ],
    [ "ResourceSet", "classOnlineMapsBingMapsElevationResult_1_1ResourceSet.html", "classOnlineMapsBingMapsElevationResult_1_1ResourceSet" ],
    [ "OnlineMapsBingMapsElevationResult", "classOnlineMapsBingMapsElevationResult.html#a26ae300cfba0fc13b36bf68c596315b7", null ],
    [ "OnlineMapsBingMapsElevationResult", "classOnlineMapsBingMapsElevationResult.html#a1198e49a4c56c0dc334f4793e17cc4b9", null ],
    [ "authenticationResultCode", "classOnlineMapsBingMapsElevationResult.html#a2f0a8c78913793f323de214d0fb5f5df", null ],
    [ "brandLogoUri", "classOnlineMapsBingMapsElevationResult.html#a00c8e5347c638d63fa4810659db4db61", null ],
    [ "copyright", "classOnlineMapsBingMapsElevationResult.html#a42cf0d31432593620e490e0c24f28fa7", null ],
    [ "resourceSets", "classOnlineMapsBingMapsElevationResult.html#afceb424f0cd7baca4e056bf150f3529c", null ],
    [ "statusCode", "classOnlineMapsBingMapsElevationResult.html#a1e4f749b9480c13613c1aaa381a257ef", null ],
    [ "statusDescription", "classOnlineMapsBingMapsElevationResult.html#a520741363c1e1f0d52d926b39180003b", null ],
    [ "traceId", "classOnlineMapsBingMapsElevationResult.html#a5d2f9ff53ad024aa76a2dd2bbbc0c5b5", null ]
];